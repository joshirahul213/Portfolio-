# Rahul Joshi — Professional Portfolio

A responsive, static personal portfolio website designed for GitHub Pages.

## Included files
- `index.html` — all page content and sections
- `styles.css` — responsive dark AI-inspired visual design
- `script.js` — mobile navigation and current year
- `assets/` — reserved for your resume or future images

## Before publishing — personalize these details
Open `index.html` and replace:
1. `YOUR_EMAIL@example.com` with your professional email address.
2. `https://www.linkedin.com/in/YOUR-LINKEDIN-HANDLE/` with your actual LinkedIn profile URL.
3. Review role titles, certification names and project descriptions to ensure they match your final CV.
4. Add a PDF resume to `assets/` if you want a resume-download button (not included because no resume file was supplied).

The earlier employer entries are intentionally shown without dates because the dates previously discussed overlap. Add confirmed dates and titles before publishing.

## Publish using GitHub Pages (free)
1. Sign in to https://github.com/ or create an account.
2. Create a **Public** repository named exactly `YOUR-GITHUB-USERNAME.github.io`.
3. Upload `index.html`, `styles.css`, `script.js` and the `assets` folder to the repository root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for the Pages deployment to finish. Your site will be at `https://YOUR-GITHUB-USERNAME.github.io`.

## Updating the site
Edit `index.html` for content and `styles.css` for design. Commit your changes to the `main` branch; GitHub Pages will publish the update.

## Notes
- This is a static site; it does not need a server, database or paid hosting.
- The contact links are placeholders and must be updated before sharing the site.
- The project impact metrics are based on information supplied for the portfolio and should be verified before public use.
- Do not publish confidential internal documents, customer information, screenshots or proprietary architecture.
